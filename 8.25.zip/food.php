<?php require_once('top.php'); ?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Deakin Green Book">
    <meta name="author" content="Akshay Kumar">
    <meta name="keywords" content="">

    <title>
        Deakin Green Book
    </title>

    <meta name="keywords" content="">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- theme stylesheet -->
    <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

    <!-- your stylesheet with modifications -->
    <link href="css/custom.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>

    <link rel="shortcut icon" href="favicon.png">
<style type="text/css">
	.img-responsive{
			width:700px;
			height:450px;
	}
	</style>
	<script>
	 var xmlhttp;
		if(window.XMLHttpRequest){
			xmlhttp= new XMLHttpRequest();
		}
		else{
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		xmlhttp.open("GET","detail.xml",false);
		xmlhttp.send();     
		var xmlDoc=xmlhttp.responseXML;
		
		var food=xmlDoc.getElementsByTagName("food");//get nodes of <pf> element.
		function displayType1(type){
	
		var contents="";
		for(var j=0;j<food.length;j++)
		{
		if(type==food[j].getElementsByTagName("type")[0].childNodes[0].nodeValue)//if statement judges if the parameter equal to property.
			{	
			contents+='<div class="col-md-9"><div class="row products"><div class="box"><h1 style="color:#66CDAA">';
			contents+=food[j].getElementsByTagName("type")[0].innerHTML;
			contents+='</h1><img src="';
			contents+=food[j].getElementsByTagName("image1")[0].innerHTML;
			contents+='" alt="" class="img-responsive"><h3 style="color:#66CDAA">';
			contents+=food[j].getElementsByTagName("title1")[0].innerHTML;
			contents+='</h3><hr><p>';
			contents+=food[j].getElementsByTagName("description1")[0].innerHTML;
			contents+='</p><h3 style="color:#66CDAA">';
			contents+=food[j].getElementsByTagName("title2")[0].innerHTML;
			contents+='</h3><hr><p>';
			contents+=food[j].getElementsByTagName("description2")[0].innerHTML;
			contents+='</p></div></div></div>';
			}
		
			document.getElementById("results").innerHTML=contents;
			
		}
		
		
		}
	</script>
	</head>

    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a>
                        </li>
                        <li>Eat Sustainably</li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <!-- *** MENUS AND FILTERS ***
 _________________________________________________________ -->
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Categories</h3>
                        </div>

                                               <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked category-menu">
                                <li class="active">
                                    <a href="food.php">Eat Sustainably <span class="badge pull-right">4</span></a>
                                    <ul>
                                         <li>  <a href="#" onclick="displayType1('eat less meat')">Eat Less Meat</a>
                                        </li>
                                        <li>  <a href="#" onclick="displayType1('eat organic')">Eat Orgainc</a>
                                        </li>
                                        <li><a href="#" onclick="displayType1('eat local')">Eat Local</a>
                                        </li>
										<li><a href="#" onclick="displayType1('eat seasonal')">Eat Seasonal</a>
                                    </ul>
                                </li>

                            </ul>

                        </div>
                    </div>


              </div>
       <!-- *** MENUS AND FILTERS END *** -->
              <div class="col-md-9">
                    <div class="box">
                        <h1>EAT SUSTAINABLY</h1>
                        <p>"Is it sustainable?" It's an increasingly important question to ask when it comes to agriculture and how we eat.
Sustainable eating is about choosing foods that are healthful to our environment and our bodies.</p>
                    </div>
				<div id="results">
                    <div class="box info-bar">
                        <div class="row">
                            <div class="col-sm-12 col-md-4 products-showing">
                                Showing <strong>4</strong> products
                            </div>
                        </div>
                    </div>
<!--change-------------------------------------------------------------------------------------------------------------------------------------->
                    <div class="row products" >

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                              <a href="#" onclick="displayType('eat less meat')">
								
                                                <img src="img/food1.jpg" alt="" class="img-responsive">
							
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="#" onclick="displayType1('eat less meat')">
						
                                                <img id = "imgback1" src="img/food1_2.jpg" alt="" class="img-responsive">
					
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                  <a href="#" onclick="displayType1('eat less meat')" class="invisible">
                                    <img src="img/food1.jpg" alt="" class="img-responsive">
                                </a>
                                <div class="text">
                                    <h3><a href="#" onclick="displayType1('eat less meat')">Eat Less Meat</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                          <a href="#" onclick="displayType1('eat less meat')" class="btn btn-primary">View detail</a>

                                    </p>
                                </div>
                                <!-- /.text -->
                            </div>
                            <!-- /.product -->
                        </div>

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                             <a href="#" onclick="displayType1('eat organic')">
                                                <img src="img/food2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                        <div class="back">
                                             <a href="#" onclick="displayType1('eat organic')">
                                                <img src="img/food2_2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                 <a href="#" onclick="displayType1('eat organic')" class="invisible">
                                    <img src="img/food2.jpg" alt="" class="img-responsive">
                                </a>
                                <div class="text">
                                    <h3> <a href="#" oonclick="displayType1('eat organic')">Eat Orgainc</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                         <a href="#" onclick="displayType1('eat organic')" class="btn btn-primary">View detail</a>
                                    </p>
                                </div>
                            </div>
                            <!-- /.product -->
                        </div>

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                           <a href="#" onclick="displayType1('eat local')">
                                                <img src="img/food3.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="#" onclick="displayType1('eat local')">
                                                <img src="img/food3_2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a href="#" onclick="displayType1('eat local')" class="invisible">
                                    <img src="img/food3.jpg" alt="" class="img-responsive">
                                </a>
                                <div class="text">
                                    <h3><a href="#" onclick="displayType1('eat local')">Eat Local</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                        <a href="#" onclick="displayType1('eat local')" class="btn btn-primary">View detail</a>

                                    </p>

                                </div>
                                <!-- /.text -->
                            </div>
                            <!-- /.product -->
                        </div>


                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                            <a href="#" onclick="displayType1('eat seasonal')">
                                                <img src="img/food4.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="#" onclick="displayType1('eat seasonal')">
                                                <img src="img/food4_2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a href="#" onclick="displayType1('eat seasonal')" class="invisible">
                                    <img src="img/food4.jpg" alt="" class="img-responsive">
                                </a>
                                <div class="text">
                                    <h3><a href="#" onclick="displayType1('eat seasonal')">Eat Seasonal</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                        <a href="#" onclick="displayType1('eat seasonal')" class="btn btn-primary">View detail</a>

                                    </p>

                                </div>
                            </div>
                            <!-- /.product -->
                        </div>
                    </div>
                    <!-- /.products -->

                </div>
				  </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>	

	<div id="advantages">

                <div class="container">
                    <div class="same-height-row">
                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-heart"></i>
                                </div>

                                <h3><a href="#">Sustainability Map</a></h3>
                                <p> Could/should we have our own sustainability map?</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-tags"></i>
                                </div>

                                <h3><a href="#">Getting Involved</a></h3>
                                <p>Community gardens, Deakin Sustainable Food Movement, Student for Sustainable Living- Reduce your Juice Game, Green Impact, Green Labs</p>
                            </div>
                        </div>

                        <div class="col-sm-4">
                            <div class="box same-height clickable">
                                <div class="icon"><i class="fa fa-thumbs-up"></i>
                                </div>

                                <h3><a href="#">100% satisfaction guaranteed</a></h3>
                                <p>Free returns on everything for 1 month.</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container -->
            </div>
            <!-- /#advantages -->

            <!-- *** ADVANTAGES END *** -->


<!-- *** FOOTER ***
 _________________________________________________________ -->
        <div id="footer" data-animate="fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <h4>Information</h4>

                        <ul>
                            <li><a href="aboutus.php">About us</a>
                            </li>
                            <li><a href="terms.php">Terms and conditions</a>
                            </li>
                            <li><a href="faq.php">FAQ</a>
                            </li>
                            <li><a href="contact.php">Contact us</a>
                            </li>
                        </ul>

                        <hr>

                        <h4>User section</h4>

                        <ul>
                            <li><a href="#" data-toggle="modal" data-target="#login-modal">Login</a>
                            </li>
                            <li><a href="register.php">Regiter</a>
                            </li>
                        </ul>

                        <hr class="hidden-md hidden-lg hidden-sm">

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>Top categories</h4>

                        <h5>Food</h5>

                        <ul>
                            <li><a href="food.php">Eat Sustainably</a>
                            </li>
                            <li><a href="food.php">Waste</a>
                            </li>
							<li><a href="food.php">Eat on Campus</a>
                            </li>

                        </ul>

                        <h5>Transport</h5>
                        <ul>
                            <li><a href="transport.php">Public Transport</a>
                            </li>
                            <li><a href="transport.php">Active Transport</a>
                            </li>
                            <li><a href="transport.php">Flexi Car</a>
                            </li>

                        </ul>

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->

                    <div class="col-md-3 col-sm-6">

                        <h4>Where to find us</h4>

                        <p><strong>Deakin University</strong>
                            <br>Burwood Highway
                            <br>Burwood
                            <br>Victoria 3125
                            <br>
                            <strong>Australia</strong>
                        </p>

                        <a href="contact.php">Go to contact page</a>

                        <hr class="hidden-md hidden-lg">

                    </div>
                    <!-- /.col-md-3 -->


                    <div class="col-md-3 col-sm-6">

                        <h4>Stay in touch</h4>

                        <p class="social">
                            <a href="#" class="facebook external" data-animate-hover="shake"><i class="fa fa-facebook"></i></a>
                            <a href="#" class="twitter external" data-animate-hover="shake"><i class="fa fa-twitter"></i></a>
                            <a href="#" class="instagram external" data-animate-hover="shake"><i class="fa fa-instagram"></i></a>
                            <a href="#" class="gplus external" data-animate-hover="shake"><i class="fa fa-google-plus"></i></a>
                            <a href="#" class="email external" data-animate-hover="shake"><i class="fa fa-envelope"></i></a>
                        </p>


                    </div>
                    <!-- /.col-md-3 -->

                </div>
                <!-- /.row -->

            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->


        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">© 2018 Deakin University</p>

                </div>

            </div>
      </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>

</body>

</html>