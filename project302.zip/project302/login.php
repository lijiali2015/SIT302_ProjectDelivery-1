<?php
	@session_start();

	require_once('includes/library.php');

	$login_problem='';
	$email="";
	$password="";

	// check that the email has been posted back
	// verify details against the database
	$email = $_POST['email'];
	$password = $_POST['password'];

	$login_result = user_login($email,$password);

	// successful login, create session

	if($login_result==true)
	{
		$_SESSION['login_email']=$email;
		$_SESSION['login_name']=get_user_name($email);
		header('Location: index.php?message=Login+successful');
		exit();
	}
	else
	{
		$login_problem='Invalid email or password. Try again later.';
		header('Location: index.php?message=Invalid+login');
		exit();
	}
?>
