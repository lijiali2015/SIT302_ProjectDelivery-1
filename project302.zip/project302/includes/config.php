<?php
	define('DATABASE','wastedisposal');
	define('USER','root');
	define('PASSWORD','');
	define('SERVER','localhost');
?>