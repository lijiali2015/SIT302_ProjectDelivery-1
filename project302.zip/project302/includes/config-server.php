<?php
	define('DATABASE','dbname');
	define('USER','dbuser');
	define('PASSWORD','dbpassword');
	define('SERVER','dbserver');
?>