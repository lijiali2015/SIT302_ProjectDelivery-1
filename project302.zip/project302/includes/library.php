<?php
	require_once('includes/config.php');

	function connect() {
		global $conn;
		if ($conn) return $conn;
		$conn = mysql_connect(SERVER, USER, PASSWORD);
		mysql_select_db(DATABASE, $conn);
		return $conn;
	}

	// get users name
	function get_user_name($email)
	{
		$conn = connect();

		$sql="select * from users where upper(email)='".strtoupper($project_id)."'";

		$result=mysql_query($sql,$conn);

		$total_row_count=mysql_numrows($result);
		$tot=0;

		// get the users name
		$name="";
		while($row=mysql_fetch_assoc($result))
		{
			$tot=$row['name'];
		}
		return $name;
	}

	// user login
	function user_login($email,$password)
	{
		$conn = connect();

		$sql="select * from users where upper(email)='". addslashes($email) ."' AND password='".addslashes($password)."'";
		echo $sql;
		$result=mysql_query($sql,$conn);

		$total_row_count=mysql_numrows($result);
		$count=0;
		$login=false;

		while($count<$total_row_count)
		{
			$login=true;
			$count=$count+1;
		}

		return $login;
	}

	// function user registration
	function user_register($email,$password,$name)
	{
		$conn = connect();

		// check if user name is already in used
		$sql="select * from users where upper(email)='". $email ."'";
		$result=mysql_query($sql,$conn);

		$total_row_count=mysql_numrows($result);
		$count=0;
		$already=false;

		while($count<$total_row_count)
		{
			$already=true;
			$count=$count+1;
		}

		// return false if email address is already in use
		if($already==true)
		{
			return false;
		}
		else
		{
			$sql="insert into users (email,password,name) values ('$email','$password','$name')";
			$result=mysql_query($sql,$conn);
			return true;
		}
	}

?>