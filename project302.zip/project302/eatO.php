<?php require_once('top.php'); ?>

    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a>
                        </li>
                        <li>Eat Sustainably</li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <!-- *** MENUS AND FILTERS *** -->
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Categories</h3>
                        </div>

                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked category-menu">
                                <li class="active">
                                    <a href="food.php">Eat Sustainably <span class="badge pull-right">4</span></a>
                                    <ul>
                                        <li><a href="eatlessmeat.php">Eat Less Meat</a>
                                        </li>
                                        <li><a href="eatO.php">Eat Orgainc</a>
                                        </li>
                                        <li><a href="eatlocal.php">Eat Local</a>
                                        </li>
										<li><a href="eatseasonal.php">Eat Seasonal</a>
                                        </li>
                                    </ul>
                                </li>

                            </ul>

                        </div>
                    </div>

                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Nutrition<a class="btn btn-xs btn-danger pull-right" href="#"><i class="fa fa-times-circle"></i> Clear</a></h3>
                        </div>

                        <div class="panel-body">

                            <form>
                                <div class="form-group">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox">fat
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox">protein
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox">cellulose
                                        </label>
                                    </div>
									<div class="checkbox">
                                        <label>
                                            <input type="checkbox">sugar
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox">vitamin
                                        </label>
                                    </div>
                                </div>

                                <button class="btn btn-default btn-sm btn-primary"><i class="fa fa-pencil"></i> Apply</button>

                            </form>

                        </div>
				  </div>

				<div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Price <a class="btn btn-xs btn-danger pull-right" href="#"><i class="fa fa-times-circle"></i> Clear</a></h3>
                        </div>

                        <div class="panel-body widget price">
							<form>

								<!-- <input type="range" min="0" max="2000" step="50" />  -->
								<div class="widget-desc">
									<div class="slider-range">
										<div data-min="10" data-max="1000" data-unit="$" class="slider-range-price ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" data-value-min="10" data-value-max="1000" data-label-result="">
											<div class="ui-slider-range ui-widget-header ui-corner-all"></div>
											<span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
											<span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0"></span>
										</div>
										<div class="range-price checkbox">$10 - $1000</div>
									</div>
								</div>
									<button class="btn btn-default btn-sm btn-primary"><i class="fa fa-pencil"></i> Apply</button>

                            </form>

						</div>
                    </div>
              </div>
       <!-- *** MENUS AND FILTERS END *** -->
              <div class="col-md-9">
                    <div class="box">
                        <h1>Eat Orgainc</h1>
                        <p>You don’t need a garden and it takes little effort to grow a few
						pots of your favourite herbs and vegetables and it’s so rewarding.
						You can grow anywhere, on windowsills, on the porch, or on the driveway.
						Start with herbs as they can be so expensive to buy and take up little room.
						Try up-cycling your empty egg boxes into planters for seedlings and using
						old bean cans and milk bottles for plant pots.</p>
                    </div>

                    <div class="box info-bar">
                        <div class="row">
                            <div class="col-sm-12 col-md-4 products-showing">
                                Showing <strong>3</strong> of <strong>6</strong> products
                            </div>

                            <div class="col-sm-12 col-md-8  products-number-sort">
                                <div class="row">
                                    <form class="form-inline">
                                        <div class="col-md-6 col-sm-6">
                                            <div class="products-number">
                                                <strong>Show</strong>  <a href="food.php" class="btn btn-default btn-sm btn-primary"  >3</a>
<!--change-------------------------------------------------------------------------------------------------------------------------------------->
												<a  href="show6.php" class="btn btn-default btn-sm" >6</a>
												<a href="show6.php" class="btn btn-default btn-sm" >All</a> food
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="products-sort-by">
                                                <strong>Sort by</strong>
                                                <select name="sort-by" class="form-control">
                                                    <option>nutrition: low-high</option>
													<option>nutrition: high-low</option>
                                                    <!--<option>Sales first</option>-->
                                                </select>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
<!--change-------------------------------------------------------------------------------------------------------------------------------------->
                    <div class="row products" id = "furnitureContent">

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                            <a href="detail.php">
								<!--------------------------------------------------------------------->
                                                <img src="img/eat1.png" alt="" class="img-responsive">
								<!--------------------------------------------------------------------->
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="detail.php">
								<!--------------------------------------------------------------------->
                                                <img id = "imgback1" src="img/eat1.png" alt="" class="img-responsive">
								<!--------------------------------------------------------------------->
                                            </a>
                                        </div>
                                    </div>
                                </div>


                                <a href="detail.php" class="invisible">
                                    <img src="img/eat1.png" alt="" class="img-responsive">
                                </a>
								<p></p>
									<p></p>
                                <div class="text">
                                    <h3><a href="detail.php">Eat Orgainc</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                        <a href="detail.php" class="btn btn-default">View detail</a>

                                    </p>
                                </div>
                                <!-- /.text -->
                            </div>
                            <!-- /.product -->
                        </div>

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                            <a href="detail.php">
                                                <img src="img/eat2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="detail.php">
                                                <img src="img/eat2.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a href="detail.php" class="invisible">
                                    <img src="img/eat2.jpg" alt="" class="img-responsive">
                                </a>
                                <div class="text">
                                    <h3><a href="detail.php">Eat Orgainc</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                        <a href="detail.php" class="btn btn-default">View detail</a>

                                    </p>
                                </div>
                                <!-- /.text -->

                                <!-- <div class="ribbon sale">
                                    <div class="theribbon">SALE</div>
                                    <div class="ribbon-background"></div>
                                </div>
                                <!-- /.ribbon -->

                                <!-- <div class="ribbon new">
                                    <div class="theribbon">NEW</div>
                                    <div class="ribbon-background"></div>
                                </div> -->
                                <!-- /.ribbon -->

                                <!-- <div class="ribbon gift">
                                    <div class="theribbon">GIFT</div>
                                    <div class="ribbon-background"></div>
                                </div> -->
                                <!-- /.ribbon -->
                            </div>
                            <!-- /.product -->
                        </div>

                        <div class="col-md-4 col-sm-6">
                            <div class="product">
                                <div class="flip-container">
                                    <div class="flipper">
                                        <div class="front">
                                            <a href="detail.php">
                                                <img src="img/eat3.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                        <div class="back">
                                            <a href="detail.php">
                                                <img src="img/eat3.jpg" alt="" class="img-responsive">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <a href="detail.php" class="invisible">
                                    <img src="img/eat3.jpg" alt="" class="img-responsive">
                                </a>
								<p></p>
								<p></p>
								<p></p>
								<p></p>
                                <div class="text">
                                    <h3><a href="detail.php">Eat Orgainc</a></h3>
                                    <p class="price"></p>
                                    <p class="buttons">
                                        <a href="detail.php" class="btn btn-default">View detail</a>

                                    </p>

                                </div>
                                <!-- /.text -->
                            </div>
                            <!-- /.product -->
                        </div>



                        <!-- /.col-md-4 -->
                    </div>
                    <!-- /.products -->
<!--chang pagination------------------------------------------------------------------------------------------------------------->
                    <div class="pages">

						<!--
                        <p class="loadMore">
                            <a href="#" class="btn btn-primary btn-lg"><i class="fa fa-chevron-down"></i> Load more</a>
                        </p>
						-->

                        <ul class="pagination">
                            <li><a href="#">&laquo;</a>
                            </li>
                            <li class="active">1
                            </li>
                            <li><a href="#">2</a>
                            </li>
                            <li><a href="#">3</a>
                            </li>
                            <li><a href="#">4</a>
                            </li>
                            <li><a href="#">5</a>
                            </li>
                            <li><a href="#">&raquo;</a>
                            </li>
                        </ul>
                    </div>

<!------chang pagination------------------------------------------------------------------------------------------------------------------------->
                </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">© 2018 Universal Ltd.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="https://bootstrapious.com/e-commerce-templates">Bootstrapious.com</a>
                         <!-- Not removing these links is part of the license conditions of the template. Thanks for understanding :) If you want to use the template without the attribution links, you can do so after supporting further themes development at https://bootstrapious.com/donate  -->
                    </p>
                </div>
            </div>
      </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->




    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>


</body>

</html>